#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
python3 "$ROOT/tests/test_stage4_static.py"
node "$ROOT/tests/test_stage2_regression.js"
node "$ROOT/tests/test_stage3.js"
node "$ROOT/tests/test_stage4_native_bridge.js" "$ROOT"
echo "ALL_STAGE4_SOURCE_CHECKS_PASS"
