const fs=require('fs'),vm=require('vm'),crypto=require('crypto');
const ctx={console,crypto:crypto.webcrypto,TextEncoder,TextDecoder,setTimeout,clearTimeout,AbortController,fetch:async()=>{throw Error('offline test')},confirm:()=>true,navigator:{onLine:true},localStorage:{getItem:()=>null,setItem:()=>{},removeItem:()=>{}},window:{addEventListener:()=>{}},document:{hidden:false,querySelector:()=>null,querySelectorAll:()=>[],addEventListener:()=>{},body:{appendChild:()=>{}}}};
ctx.global=ctx;ctx.globalThis=ctx;vm.createContext(ctx);
vm.runInContext(fs.readFileSync('/mnt/data/kkwallet_stage4/KKWallet-v0.4.0-Native/app/src/main/assets/game/wallet_core.js','utf8'),ctx);
ctx.KoraCore=ctx.KoraCore;
vm.runInContext(fs.readFileSync('/mnt/data/kkwallet_stage4/KKWallet-v0.4.0-Native/app/src/main/assets/game/app.js','utf8'),ctx);
(async()=>{
 const C=ctx.KoraCore;
 const m='test test test test test test test test test test test junk';
 const vault=await C.encryptMnemonic(m,'12345678'); const opened=await C.decryptMnemonic(vault,'12345678'); if(opened!==m) throw Error('vault roundtrip failed'); let rejected=false; try{await C.decryptMnemonic(vault,'87654321')}catch(_){rejected=true} if(!rejected) throw Error('wrong PIN accepted');
 const pk=await C.derivePrivateKey(m); const addr=C.checksumAddress(C.privateToAddress(pk));
 if(addr!=='0xf39Fd6e51aad88F6F4ce6aB8827279cffFb92266') throw Error('derive mismatch '+addr);
 const good='0x52908400098527886E0F7030069857D2E4169EE7';
 const bad='0x52908400098527886E0F7030069857D2E4169Ee7';
 if(!C.validAddress(good)||C.validAddress(bad)||C.validAddress('0x0000000000000000000000000000000000000000')) throw Error('address validation failed');
 const legacy={nonce:0n,gasPrice:1000000000n,gasLimit:21000n,to:'0x3535353535353535353535353535353535353535',value:1n,data:'0x',chainId:1n}; const l1=await C.signLegacyTx(legacy,pk),l2=await C.signLegacyTx(legacy,pk); if(l1!==l2||!l1.startsWith('0x')) throw Error('legacy signing failed');
 const tx={chainId:1n,nonce:0n,maxPriorityFeePerGas:1500000000n,maxFeePerGas:30000000000n,gasLimit:21000n,to:'0x3535353535353535353535353535353535353535',value:1000000000000000n,data:'0x'};
 const a=await C.signEip1559Tx(tx,pk),b=await C.signEip1559Tx(tx,pk);
 if(a!==b||!a.startsWith('0x02')||a.length<100) throw Error('type2 signing failed');
 const short=vm.runInContext("gasShortageMessage(230000000000000n,0n,'XPL')",ctx);
 const shortPartial=vm.runInContext("gasShortageMessage(230000000000000n,50000000000000n,'XPL')",ctx); if(shortPartial!=='支付需网络费 0.00023 XPL，目前缺少 0.00018 XPL，请链上充币以支付网络费。') throw Error('partial shortage mismatch '+shortPartial);
 if(short!=='支付需网络费 0.00023 XPL，目前缺少 0.00023 XPL，请链上充币以支付网络费。') throw Error('message mismatch '+short);
 vm.runInContext(`address='${addr}'`,ctx);
 // EIP-1559 quote mock: estimateGas 21000, baseFee 10 gwei, priority 2 gwei => 22 gwei maxFee, 15% gas margin=24150
 vm.runInContext(`rpcOn=async function(k,m,p){if(m==='eth_estimateGas')return '0x5208';if(m==='eth_getBlockByNumber')return {baseFeePerGas:'0x2540be400'};if(m==='eth_maxPriorityFeePerGas')return '0x77359400';throw Error(m)}`,ctx);
 const q=await vm.runInContext("quoteGas('eth',{from:address,to:'0x3535353535353535353535353535353535353535',value:'0x0',data:'0x'})",ctx);
 if(q.type!=='eip1559'||q.gasLimit!==24150n||q.maxFeePerGas!==22000000000n||q.required!==531300000000000n) throw Error('EIP quote failed '+JSON.stringify({...q,gasLimit:String(q.gasLimit),maxFeePerGas:String(q.maxFeePerGas),required:String(q.required)}));
 // EIP-1559 priority fallback through gasPrice
 vm.runInContext(`rpcOn=async function(k,m,p){if(m==='eth_estimateGas')return '0x5208';if(m==='eth_getBlockByNumber')return {baseFeePerGas:'0x2540be400'};if(m==='eth_maxPriorityFeePerGas')throw Error('unsupported');if(m==='eth_gasPrice')return '0x2cb417800';throw Error(m)}`,ctx);
 const qf=await vm.runInContext("quoteGas('eth',{from:address,to:'0x3535353535353535353535353535353535353535',value:'0x0',data:'0x'})",ctx);
 if(qf.type!=='eip1559'||qf.maxPriorityFeePerGas!==2000000000n||qf.maxFeePerGas!==22000000000n) throw Error('priority fallback failed');
 // estimate failure must block instead of silently using a hard-coded gas limit
 vm.runInContext(`rpcOn=async function(k,m,p){if(m==='eth_estimateGas')throw Error('estimate rejected');throw Error(m)}`,ctx);
 let estimateRejected=false; try{await vm.runInContext("quoteGas('eth',{from:address,to:'0x3535353535353535353535353535353535353535',value:'0x0',data:'0x'})",ctx)}catch(e){estimateRejected=String(e.message).includes('网络费估算失败')} if(!estimateRejected) throw Error('estimate fallback was unsafe');
 // legacy quote mock
 vm.runInContext(`rpcOn=async function(k,m,p){if(m==='eth_estimateGas')return '0x5208';if(m==='eth_getBlockByNumber')return {};if(m==='eth_gasPrice')return '0x3b9aca00';throw Error(m)}`,ctx);
 const q2=await vm.runInContext("quoteGas('bnb',{from:address,to:'0x3535353535353535353535353535353535353535',value:'0x0',data:'0x'})",ctx);
 if(q2.type!=='legacy'||q2.gasLimit!==24150n||q2.gasPrice!==1000000000n||q2.required!==24150000000000n) throw Error('legacy quote failed');
 console.log('STAGE2_CORE_PASS');
 console.log('address',addr);console.log('type2_prefix',a.slice(0,18));console.log('gas_message',short);console.log('eip1559_required',String(q.required));console.log('legacy_required',String(q2.required));
})().catch(e=>{console.error(e);process.exit(1)});
