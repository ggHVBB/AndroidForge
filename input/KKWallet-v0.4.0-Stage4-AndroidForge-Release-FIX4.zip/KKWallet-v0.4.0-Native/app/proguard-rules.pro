# Keep JavaScript bridge entry points.
-keepclassmembers class com.kora.wallet.WalletBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.kora.wallet.QrScannerActivity { *; }
-dontwarn org.slf4j.**

# Android Gradle Plugin generated Release R8 rule (Run #7).
-dontwarn groovy.lang.GroovyShell
