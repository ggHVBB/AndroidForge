package com.kora.wallet;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyInfo;
import android.security.keystore.KeyProperties;
import android.util.Base64;
import android.webkit.JavascriptInterface;

import org.bouncycastle.crypto.PBEParametersGenerator;
import org.bouncycastle.crypto.digests.SHA256Digest;
import org.bouncycastle.crypto.generators.PKCS5S2ParametersGenerator;
import org.bouncycastle.crypto.params.KeyParameter;
import org.json.JSONObject;
import org.web3j.crypto.Bip32ECKeyPair;
import org.web3j.crypto.Credentials;
import org.web3j.crypto.Keys;
import org.web3j.crypto.MnemonicUtils;
import org.web3j.crypto.RawTransaction;
import org.web3j.crypto.TransactionEncoder;
import org.web3j.utils.Numeric;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.SecureRandom;
import java.util.Arrays;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.GCMParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public final class WalletBridge {
    private static final String PREFS = "kk_wallet_native_v1";
    private static final String PREF_VAULT_IV = "vault_outer_iv";
    private static final String PREF_VAULT_CT = "vault_outer_ct";
    private static final String PREF_LEGACY_IV = "legacy_outer_iv";
    private static final String PREF_LEGACY_CT = "legacy_outer_ct";
    private static final String KEY_ALIAS = "kk_wallet_master_aes_v1";
    private static final int PIN_ITERATIONS = 600_000;
    private static final int[] ETH_PATH = {
            44 | Bip32ECKeyPair.HARDENED_BIT,
            60 | Bip32ECKeyPair.HARDENED_BIT,
            0 | Bip32ECKeyPair.HARDENED_BIT,
            0,
            0
    };

    private final MainActivity activity;
    private final SharedPreferences prefs;
    private final SecureRandom random = new SecureRandom();
    private volatile Credentials sessionCredentials;

    WalletBridge(MainActivity activity) {
        this.activity = activity;
        this.prefs = activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    @JavascriptInterface
    public String nativeVersion() { return "0.4.0-native"; }

    @JavascriptInterface
    public boolean hasVault() {
        return prefs.contains(PREF_VAULT_IV) && prefs.contains(PREF_VAULT_CT);
    }

    void stashLegacyStorage(String snapshot) {
        try {
            if (prefs.contains(PREF_LEGACY_CT)) return;
            OuterCipher outer = encryptWithKeystore(snapshot.getBytes(StandardCharsets.UTF_8));
            prefs.edit().putString(PREF_LEGACY_IV, b64(outer.iv)).putString(PREF_LEGACY_CT, b64(outer.ciphertext)).commit();
        } catch (Exception ignored) { }
    }

    @JavascriptInterface
    public boolean hasLegacyStorage() {
        return prefs.contains(PREF_LEGACY_IV) && prefs.contains(PREF_LEGACY_CT);
    }

    @JavascriptInterface
    public String getLegacyStorage() {
        try {
            String iv = prefs.getString(PREF_LEGACY_IV, null), ct = prefs.getString(PREF_LEGACY_CT, null);
            if (iv == null || ct == null) throw new IllegalStateException("没有旧版存储快照");
            byte[] plain = decryptWithKeystore(unb64(iv), unb64(ct));
            try {
                JSONObject o = ok(); o.put("snapshot", new String(plain, StandardCharsets.UTF_8)); return o.toString();
            } finally { Arrays.fill(plain, (byte) 0); }
        } catch (Exception e) { return fail(e).toString(); }
    }

    @JavascriptInterface
    public String clearLegacyStorage() {
        boolean committed = prefs.edit().remove(PREF_LEGACY_IV).remove(PREF_LEGACY_CT).commit();
        if (committed) activity.clearLegacyWebStorage();
        return committed ? ok().toString() : fail(new IllegalStateException("旧版存储清理失败")).toString();
    }

    @JavascriptInterface
    public String securityStatus() {
        try {
            SecretKey key = getOrCreateMasterKey();
            boolean hardware = false;
            try {
                SecretKeyFactory kf = SecretKeyFactory.getInstance(key.getAlgorithm(), "AndroidKeyStore");
                KeyInfo info = (KeyInfo) kf.getKeySpec(key, KeyInfo.class);
                hardware = info.isInsideSecureHardware();
            } catch (Exception ignored) { }
            JSONObject o = ok();
            o.put("hardwareBacked", hardware);
            o.put("keystore", true);
            o.put("signing", "web3j-native");
            return o.toString();
        } catch (Exception e) {
            return fail(e).toString();
        }
    }

    @JavascriptInterface
    public String generateMnemonic() {
        try {
            byte[] entropy = new byte[16];
            random.nextBytes(entropy);
            String mnemonic = MnemonicUtils.generateMnemonic(entropy);
            Arrays.fill(entropy, (byte) 0);
            JSONObject o = ok();
            o.put("mnemonic", mnemonic);
            return o.toString();
        } catch (Exception e) { return fail(e).toString(); }
    }

    @JavascriptInterface
    public String validateMnemonic(String mnemonic) {
        try {
            String clean = cleanMnemonic(mnemonic);
            if (!MnemonicUtils.validateMnemonic(clean)) throw new IllegalArgumentException("BIP39 助记词校验失败");
            JSONObject o = ok();
            o.put("valid", true);
            o.put("address", deriveAddress(clean));
            return o.toString();
        } catch (Exception e) { return fail(e).toString(); }
    }

    @JavascriptInterface
    public String deriveAddressForMnemonic(String mnemonic) {
        try {
            JSONObject o = ok();
            o.put("address", deriveAddress(cleanMnemonic(mnemonic)));
            return o.toString();
        } catch (Exception e) { return fail(e).toString(); }
    }

    @JavascriptInterface
    public synchronized String saveWallet(String mnemonic, String pin) {
        try {
            String clean = cleanMnemonic(mnemonic);
            validatePin(pin);
            if (!MnemonicUtils.validateMnemonic(clean)) throw new IllegalArgumentException("BIP39 助记词校验失败");
            String inner = encryptWithPin(clean, pin);
            OuterCipher outer = encryptWithKeystore(inner.getBytes(StandardCharsets.UTF_8));
            boolean committed = prefs.edit()
                    .putString(PREF_VAULT_IV, b64(outer.iv))
                    .putString(PREF_VAULT_CT, b64(outer.ciphertext))
                    .commit();
            if (!committed) throw new IllegalStateException("保险库写入失败");
            sessionCredentials = credentialsForMnemonic(clean);
            JSONObject o = ok();
            o.put("address", Keys.toChecksumAddress(sessionCredentials.getAddress()));
            return o.toString();
        } catch (Exception e) { return fail(e).toString(); }
    }

    @JavascriptInterface
    public synchronized String unlock(String pin) {
        try {
            validatePin(pin);
            String outerIv = prefs.getString(PREF_VAULT_IV, null);
            String outerCt = prefs.getString(PREF_VAULT_CT, null);
            if (outerIv == null || outerCt == null) throw new IllegalStateException("本机原生保险库不存在");
            byte[] plainOuter = decryptWithKeystore(unb64(outerIv), unb64(outerCt));
            String inner = new String(plainOuter, StandardCharsets.UTF_8);
            Arrays.fill(plainOuter, (byte) 0);
            String mnemonic = decryptWithPin(inner, pin);
            sessionCredentials = credentialsForMnemonic(mnemonic);
            JSONObject o = ok();
            o.put("address", Keys.toChecksumAddress(sessionCredentials.getAddress()));
            return o.toString();
        } catch (Exception e) {
            sessionCredentials = null;
            return fail(new IllegalArgumentException("密码错误或钱包数据损坏")).toString();
        }
    }

    @JavascriptInterface
    public synchronized void lock() { sessionCredentials = null; }

    void lockSession() { sessionCredentials = null; }

    @JavascriptInterface
    public synchronized String deleteWallet() {
        sessionCredentials = null;
        try {
            if (!prefs.edit().clear().commit()) throw new IllegalStateException("删除本机保险库失败");
            KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
            ks.load(null);
            if (ks.containsAlias(KEY_ALIAS)) ks.deleteEntry(KEY_ALIAS);
            return ok().toString();
        } catch (Exception e) {
            return fail(e).toString();
        }
    }

    @JavascriptInterface
    public synchronized String signLegacy(
            String chainId, String nonce, String gasPrice, String gasLimit,
            String to, String value, String data) {
        try {
            Credentials c = requireSession();
            RawTransaction tx = RawTransaction.createTransaction(
                    bi(nonce), bi(gasPrice), bi(gasLimit), normalizeTo(to), bi(value), normalizeData(data));
            byte[] signed = TransactionEncoder.signMessage(tx, bi(chainId).longValueExact(), c);
            JSONObject o = ok();
            o.put("raw", Numeric.toHexString(signed));
            return o.toString();
        } catch (Exception e) { return fail(e).toString(); }
    }

    @JavascriptInterface
    public synchronized String signEip1559(
            String chainId, String nonce, String maxPriorityFeePerGas, String maxFeePerGas,
            String gasLimit, String to, String value, String data) {
        try {
            Credentials c = requireSession();
            long cid = bi(chainId).longValueExact();
            RawTransaction tx = RawTransaction.createTransaction(
                    cid, bi(nonce), bi(gasLimit), normalizeTo(to), bi(value), normalizeData(data),
                    bi(maxPriorityFeePerGas), bi(maxFeePerGas));
            byte[] signed = TransactionEncoder.signMessage(tx, c);
            JSONObject o = ok();
            o.put("raw", Numeric.toHexString(signed));
            return o.toString();
        } catch (Exception e) { return fail(e).toString(); }
    }

    @JavascriptInterface
    public void scanQr(String target) { activity.launchQrScanner(target); }

    private Credentials requireSession() {
        Credentials c = sessionCredentials;
        if (c == null) throw new IllegalStateException("钱包已锁定，请重新解锁");
        return c;
    }

    private String deriveAddress(String mnemonic) {
        return Keys.toChecksumAddress(credentialsForMnemonic(mnemonic).getAddress());
    }

    private Credentials credentialsForMnemonic(String mnemonic) {
        byte[] seed = MnemonicUtils.generateSeed(mnemonic, "");
        try {
            Bip32ECKeyPair master = Bip32ECKeyPair.generateKeyPair(seed);
            Bip32ECKeyPair derived = Bip32ECKeyPair.deriveKeyPair(master, ETH_PATH);
            return Credentials.create(derived);
        } finally {
            Arrays.fill(seed, (byte) 0);
        }
    }

    private static String cleanMnemonic(String m) {
        if (m == null) return "";
        return m.trim().toLowerCase().replaceAll("\\s+", " ");
    }

    private static void validatePin(String pin) {
        if (pin == null || pin.length() < 8) throw new IllegalArgumentException("钱包密码至少 8 位");
        if (pin.length() > 128) throw new IllegalArgumentException("钱包密码过长");
    }

    private String encryptWithPin(String mnemonic, String pin) throws Exception {
        byte[] salt = new byte[16], iv = new byte[12];
        random.nextBytes(salt); random.nextBytes(iv);
        byte[] key = derivePinKey(pin, salt);
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.ENCRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, iv));
            byte[] ct = cipher.doFinal(mnemonic.getBytes(StandardCharsets.UTF_8));
            JSONObject o = new JSONObject();
            o.put("v", 1); o.put("iter", PIN_ITERATIONS);
            o.put("salt", b64(salt)); o.put("iv", b64(iv)); o.put("ct", b64(ct));
            return o.toString();
        } finally { Arrays.fill(key, (byte) 0); }
    }

    private String decryptWithPin(String packed, String pin) throws Exception {
        JSONObject o = new JSONObject(packed);
        int iter = o.optInt("iter", 0);
        if (iter != PIN_ITERATIONS) throw new IllegalStateException("保险库 KDF 参数异常");
        byte[] salt = unb64(o.getString("salt"));
        byte[] iv = unb64(o.getString("iv"));
        byte[] ct = unb64(o.getString("ct"));
        byte[] key = derivePinKey(pin, salt);
        try {
            Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new GCMParameterSpec(128, iv));
            return new String(cipher.doFinal(ct), StandardCharsets.UTF_8);
        } finally { Arrays.fill(key, (byte) 0); }
    }

    private static byte[] derivePinKey(String pin, byte[] salt) {
        PKCS5S2ParametersGenerator gen = new PKCS5S2ParametersGenerator(new SHA256Digest());
        byte[] password = PBEParametersGenerator.PKCS5PasswordToUTF8Bytes(pin.toCharArray());
        try {
            gen.init(password, salt, PIN_ITERATIONS);
            return ((KeyParameter) gen.generateDerivedParameters(256)).getKey();
        } finally { Arrays.fill(password, (byte) 0); }
    }

    private OuterCipher encryptWithKeystore(byte[] clear) throws Exception {
        SecretKey key = getOrCreateMasterKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.ENCRYPT_MODE, key);
        return new OuterCipher(cipher.getIV(), cipher.doFinal(clear));
    }

    private byte[] decryptWithKeystore(byte[] iv, byte[] ciphertext) throws Exception {
        SecretKey key = getOrCreateMasterKey();
        Cipher cipher = Cipher.getInstance("AES/GCM/NoPadding");
        cipher.init(Cipher.DECRYPT_MODE, key, new GCMParameterSpec(128, iv));
        return cipher.doFinal(ciphertext);
    }

    private SecretKey getOrCreateMasterKey() throws Exception {
        KeyStore ks = KeyStore.getInstance("AndroidKeyStore");
        ks.load(null);
        if (ks.containsAlias(KEY_ALIAS)) {
            return ((KeyStore.SecretKeyEntry) ks.getEntry(KEY_ALIAS, null)).getSecretKey();
        }
        try {
            return generateMasterKey(true);
        } catch (Exception strongBoxFailure) {
            return generateMasterKey(false);
        }
    }

    private SecretKey generateMasterKey(boolean preferStrongBox) throws Exception {
        KeyGenerator kg = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore");
        KeyGenParameterSpec.Builder b = new KeyGenParameterSpec.Builder(
                KEY_ALIAS, KeyProperties.PURPOSE_ENCRYPT | KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .setUserAuthenticationRequired(false);
        if (Build.VERSION.SDK_INT >= 28 && preferStrongBox) b.setIsStrongBoxBacked(true);
        kg.init(b.build());
        return kg.generateKey();
    }

    private static String normalizeData(String data) {
        if (data == null || data.trim().isEmpty()) return "0x";
        if (!data.matches("0x[0-9a-fA-F]*")) throw new IllegalArgumentException("交易 data 格式错误");
        return data;
    }

    private static String normalizeTo(String to) {
        if (to == null || !to.matches("0x[0-9a-fA-F]{40}")) throw new IllegalArgumentException("收款地址格式错误");
        return Keys.toChecksumAddress(to);
    }

    private static BigInteger bi(String s) {
        BigInteger n = new BigInteger(s);
        if (n.signum() < 0) throw new IllegalArgumentException("交易参数不能为负数");
        return n;
    }

    private static String b64(byte[] b) { return Base64.encodeToString(b, Base64.NO_WRAP); }
    private static byte[] unb64(String s) { return Base64.decode(s, Base64.NO_WRAP); }

    private static JSONObject ok() {
        JSONObject o = new JSONObject();
        try { o.put("ok", true); } catch (Exception ignored) { }
        return o;
    }

    private static JSONObject fail(Exception e) {
        JSONObject o = new JSONObject();
        try {
            o.put("ok", false);
            String msg = e.getMessage();
            o.put("error", (msg == null || msg.trim().isEmpty()) ? e.getClass().getSimpleName() : msg);
        } catch (Exception ignored) { }
        return o;
    }

    private static final class OuterCipher {
        final byte[] iv, ciphertext;
        OuterCipher(byte[] iv, byte[] ciphertext) { this.iv = iv; this.ciphertext = ciphertext; }
    }
}
