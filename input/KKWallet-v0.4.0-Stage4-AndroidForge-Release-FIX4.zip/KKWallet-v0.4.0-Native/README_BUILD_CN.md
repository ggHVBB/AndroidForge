# KK Wallet v0.4.0 Native

这是从 Stage 3 继续完成的原生安全工程。

## 构建要求
- Android Studio（支持 AGP 8.13.2）
- JDK 17
- Android SDK 36
- Gradle 8.13

打开项目后执行 `assembleDebug` 或配置你原来的正式签名后执行 `assembleRelease`。

> **重要：** 如果要覆盖安装现有 `com.kora.wallet`，必须使用之前 APK 的同一份更新签名私钥/keystore。没有原签名私钥时只能作为新的签名安装，Android 不允许用不同证书覆盖旧版。

## 安全路径
APK 内运行时：BIP39 / BIP44 / EVM 签名 -> Android 原生 Web3j；保险库 -> Android Keystore + PIN KDF 双层 AES-GCM。HTML/JS 仅负责界面、RPC 查询、Gas 估算、交易确认及广播。
