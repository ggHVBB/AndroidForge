package com.kora.wallet;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.ViewGroup;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import androidx.activity.ComponentActivity;
import androidx.annotation.Nullable;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayInputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.atomic.AtomicBoolean;

public final class MainActivity extends ComponentActivity {
    private static final int QR_REQUEST = 7004;
    private static final String APP_ORIGIN = "https://appassets.androidplatform.net";
    private WebView webView;
    private WebView legacyProbeView;
    private FrameLayout root;
    private WalletBridge bridge;
    private final AtomicBoolean probeCompleted = new AtomicBoolean(false);
    private String qrTarget = "send";
    private boolean internalSecureFlow = false;

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        webView = new WebView(this);
        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        bridge = new WalletBridge(this);
        runLegacyStorageProbe();
    }

    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    private void setupMainWebView() {
        final WebViewAssetLoader assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setMediaPlaybackRequiresUserGesture(true);
        s.setSaveFormData(false);
        if (android.os.Build.VERSION.SDK_INT >= 26) s.setSafeBrowsingEnabled(true);

        WebView.setWebContentsDebuggingEnabled(BuildConfig.DEBUG);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public android.webkit.WebResourceResponse shouldInterceptRequest(
                    WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                return !("https".equals(u.getScheme())
                        && "appassets.androidplatform.net".equals(u.getHost()));
            }
        });

        webView.addJavascriptInterface(bridge, "KoraNative");
        webView.loadUrl(APP_ORIGIN + "/assets/game/index.html");
    }

    @SuppressLint("SetJavaScriptEnabled")
    private void runLegacyStorageProbe() {
        // v0.3.1 used this exact file URL. Reusing the exact legacy entry URL is intentional:
        // file:// localStorage isolation is implementation-defined, so probing a different file
        // (for example legacy_migrate.html) could miss an existing wallet on some WebView builds.
        legacyProbeView = new WebView(this);
        legacyProbeView.setVisibility(View.INVISIBLE);
        WebSettings s = legacyProbeView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        legacyProbeView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme()) && "/android_asset/game/index.html".equals(u.getPath())) {
                    byte[] inert = "<!doctype html><meta charset=utf-8><title>KK migration</title>"
                            .getBytes(StandardCharsets.UTF_8);
                    return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(inert));
                }
                return super.shouldInterceptRequest(view, request);
            }

            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript(
                        "JSON.stringify(Object.fromEntries(Object.keys(localStorage).map(k=>[k,localStorage.getItem(k)])))",
                        MainActivity.this::acceptLegacySnapshotFromJavascript);
            }
        });
        root.addView(legacyProbeView, new FrameLayout.LayoutParams(1, 1));
        legacyProbeView.loadUrl("file:///android_asset/game/index.html");
        new Handler(Looper.getMainLooper()).postDelayed(this::finishLegacyProbe, 2500);
    }

    private void acceptLegacySnapshotFromJavascript(String encoded) {
        try {
            if (encoded != null && !"null".equals(encoded)) {
                Object decoded = new org.json.JSONTokener(encoded).nextValue();
                if (decoded instanceof String) {
                    String snapshot = (String) decoded;
                    if (!snapshot.trim().isEmpty() && !"{}".equals(snapshot.trim())) {
                        bridge.stashLegacyStorage(snapshot);
                    }
                }
            }
        } catch (Exception ignored) {
            // A malformed/nonexistent legacy snapshot must never block startup.
        } finally {
            finishLegacyProbe();
        }
    }

    private void finishLegacyProbe() {
        if (!probeCompleted.compareAndSet(false, true)) return;
        if (legacyProbeView != null) {
            root.removeView(legacyProbeView);
            legacyProbeView.destroy();
            legacyProbeView = null;
        }
        setupMainWebView();
    }

    void clearLegacyWebStorage() {
        runOnUiThread(() -> {
            WebView cleaner = new WebView(this);
            cleaner.setVisibility(View.INVISIBLE);
            cleaner.getSettings().setJavaScriptEnabled(true);
            cleaner.getSettings().setDomStorageEnabled(true);
            cleaner.getSettings().setAllowFileAccess(true);
            cleaner.getSettings().setAllowUniversalAccessFromFileURLs(false);
            root.addView(cleaner, new FrameLayout.LayoutParams(1, 1));
            cleaner.getSettings().setAllowFileAccessFromFileURLs(false);
            cleaner.setWebViewClient(new WebViewClient() {
                @Override
                public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                    Uri u = request.getUrl();
                    if ("file".equals(u.getScheme()) && "/android_asset/game/index.html".equals(u.getPath())) {
                        byte[] inert = "<!doctype html><meta charset=utf-8><title>KK cleanup</title>"
                                .getBytes(StandardCharsets.UTF_8);
                        return new WebResourceResponse("text/html", "UTF-8", new ByteArrayInputStream(inert));
                    }
                    return super.shouldInterceptRequest(view, request);
                }

                @Override public void onPageFinished(WebView view, String url) {
                    view.evaluateJavascript("localStorage.removeItem('kora_vault');", value -> {
                        root.removeView(view);
                        view.destroy();
                    });
                }
            });
            // Use the same exact legacy URL so the old origin's vault is actually cleared.
            cleaner.loadUrl("file:///android_asset/game/index.html");
        });
    }

    void launchQrScanner(String target) {
        runOnUiThread(() -> {
            qrTarget = "token".equals(target) ? "token" : "send";
            internalSecureFlow = true;
            Intent i = new Intent(this, QrScannerActivity.class);
            startActivityForResult(i, QR_REQUEST);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != QR_REQUEST) return;
        internalSecureFlow = false;
        if (resultCode == RESULT_OK && data != null) {
            String raw = data.getStringExtra(QrScannerActivity.EXTRA_RESULT);
            if (raw == null) raw = "";
            String js = "window.KoraNativeQrResult&&window.KoraNativeQrResult("
                    + JSONObject.quote(qrTarget) + "," + JSONObject.quote(raw) + ");";
            webView.evaluateJavascript(js, null);
        } else {
            webView.evaluateJavascript(
                    "window.KoraNativeQrError&&window.KoraNativeQrError('未识别二维码');", null);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Keep the wallet session unlocked while the user temporarily switches apps.
        // Explicit Lock and process destruction still clear session credentials.
        if (legacyProbeView != null) {
            legacyProbeView.destroy();
            legacyProbeView = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (bridge != null) bridge.lockSession();
        if (webView != null) {
            webView.removeJavascriptInterface("KoraNative");
            webView.destroy();
        }
        super.onDestroy();
    }
}
