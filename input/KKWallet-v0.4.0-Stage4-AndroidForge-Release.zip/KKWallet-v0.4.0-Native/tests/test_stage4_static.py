from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
manifest=(root/'app/src/main/AndroidManifest.xml').read_text()
main=(root/'app/src/main/java/com/kora/wallet/MainActivity.java').read_text()
bridge=(root/'app/src/main/java/com/kora/wallet/WalletBridge.java').read_text()
qr=(root/'app/src/main/java/com/kora/wallet/QrScannerActivity.java').read_text()
js=(root/'app/src/main/assets/game/app.js').read_text()
html=(root/'app/src/main/assets/game/index.html').read_text()
gradle=(root/'app/build.gradle').read_text()
checks={
 'clean_package': 'com.linqicha.fixed' not in '\n'.join(p.read_text(errors='ignore') for p in root.rglob('*') if p.is_file() and p.suffix in {'.java','.xml','.gradle','.js','.html','.md','.txt'}),
 'minimal_permissions': 'android.permission.INTERNET' in manifest and 'android.permission.CAMERA' in manifest and 'REQUEST_INSTALL_PACKAGES' not in manifest,
 'backup_off': 'android:allowBackup="false"' in manifest,
 'cleartext_off': 'usesCleartextTraffic="false"' in manifest,
 'flag_secure': 'FLAG_SECURE' in main and 'FLAG_SECURE' in qr,
 'asset_loader': 'WebViewAssetLoader' in main and 'setAllowFileAccess(false)' in main and 'MIXED_CONTENT_NEVER_ALLOW' in main,
 'keystore': 'AndroidKeyStore' in bridge and 'AES/GCM/NoPadding' in bridge and 'PIN_ITERATIONS = 600_000' in bridge,
 'native_web3j': 'TransactionEncoder.signMessage' in bridge and 'MnemonicUtils.generateMnemonic' in bridge and 'Bip32ECKeyPair.deriveKeyPair' in bridge,
 'eip1559_native': 'signEip1559' in bridge and 'RawTransaction.createTransaction' in bridge,
 'camera_native': 'ProcessCameraProvider' in qr and 'BarcodeScanning.getClient' in qr,
 'qr_ui': 'id="scanSendQr"' in html and 'id="scanTokenQr"' in html and 'KoraNativeQrResult' in js,
 'legacy_upgrade_migration': 'file:///android_asset/game/index.html' in main and 'acceptLegacySnapshotFromJavascript' in main and 'stashLegacyStorage' in bridge and 'clearLegacyWebStorage' in main and 'loadLegacyStorageSnapshot' in js,
 'native_vault_path': 'window.KoraNative.saveWallet' in js and 'window.KoraNative.unlock' in js and 'localStorage.removeItem(\'kora_vault\')' in js,
 'native_sign_path': 'window.KoraNative.signEip1559' in js and 'window.KoraNative.signLegacy' in js,
 'offline_bip39_path': 'window.KoraNative.generateMnemonic' in js and 'window.KoraNative.validateMnemonic' in js,
 'version': 'v0.4.0 Security · Native' in html,
 'dependencies': "androidx.camera:camera-core:1.6.2" in gradle and "androidx.webkit:webkit:1.17.0" in gradle and "androidx.lifecycle:lifecycle-process:2.11.0" in gradle and "org.web3j:crypto:4.14.0" in gradle,
 'process_background_lock': 'ProcessLifecycleOwner.get()' in main and 'secureLockFromSystem' in main,
 'keystore_cryptographic_delete': 'ks.deleteEntry(KEY_ALIAS)' in bridge,
}
failed=[k for k,v in checks.items() if not v]
for k,v in checks.items(): print(k, 'PASS' if v else 'FAIL')
if failed: print('FAILED', failed); sys.exit(1)
print('STAGE4_STATIC_PASS')
