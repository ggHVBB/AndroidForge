# Keep JavaScript bridge entry points.
-keepclassmembers class com.kora.wallet.WalletBridge {
    @android.webkit.JavascriptInterface <methods>;
}
-keep class com.kora.wallet.QrScannerActivity { *; }
-dontwarn org.slf4j.**
